import { useState, useEffect } from "react";
import { View, Text, TextInput, TouchableOpacity, ScrollView, Alert, ActivityIndicator } from "react-native";
import { router } from "expo-router";
import { SafeAreaView } from "react-native-safe-area-context";
import { ChevronLeft } from "lucide-react-native";
import { useAuth } from "../../lib/auth-context";
import { listUsers, inviteUser } from "../../lib/api";
import { colors } from "../../components/ui";

export default function TeamManagementScreen() {
  const { auth } = useAuth();
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [role, setRole] = useState<"manager" | "owner">("manager");
  const [inviting, setInviting] = useState(false);

  async function loadTeam() {
    if (!auth.token) return;
    setLoading(true);
    try {
      const data = await listUsers(auth.token);
      setUsers(data);
    } catch (e: any) {
      Alert.alert("Error", e.message || "Failed to load team");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadTeam();
  }, [auth.token]);

  async function handleInvite() {
    if (!name || !phone || !auth.token) return;
    setInviting(true);
    try {
      await inviteUser(auth.token, phone, name, role);
      Alert.alert("Success", "Invitation sent");
      setName("");
      setPhone("");
      loadTeam();
    } catch (e: any) {
      Alert.alert("Error", e.message || "Failed to invite user");
    } finally {
      setInviting(false);
    }
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#F7F7F8" }}>
      <View style={{ flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingTop: 8, paddingBottom: 8 }}>
        <TouchableOpacity onPress={() => router.back()} style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border, alignItems: "center", justifyContent: "center" }}>
          <ChevronLeft size={24} color={colors.textMain} />
        </TouchableOpacity>
        <Text style={{ fontSize: 17, fontWeight: "800", color: colors.textMain, marginLeft: 12 }}>Team Management</Text>
      </View>

      <ScrollView contentContainerStyle={{ paddingHorizontal: 24, paddingTop: 24, paddingBottom: 40, gap: 32 }}>
        {/* Team List */}
        <View>
          <Text style={{ fontSize: 17, fontWeight: "800", color: colors.textMain, marginBottom: 12 }}>Current Team</Text>
          {loading ? (
            <ActivityIndicator />
          ) : (
            <View style={{ backgroundColor: "white", borderRadius: 24, borderWidth: 1, borderColor: colors.border, padding: 16, gap: 12 }}>
              {users.map(u => (
                <View key={u.id} style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", borderBottomWidth: 1, borderBottomColor: colors.border, paddingBottom: 12 }}>
                  <View>
                    <Text style={{ fontSize: 15, fontWeight: "800", color: colors.textMain }}>{u.name || "Unknown"}</Text>
                    <Text style={{ fontSize: 13, color: colors.textMuted }}>{u.phone}</Text>
                  </View>
                  <Text style={{ fontSize: 13, fontWeight: "700", color: colors.primary, textTransform: "capitalize" }}>{u.role}</Text>
                </View>
              ))}
              {users.length === 0 && <Text style={{ color: colors.textMuted }}>No team members found.</Text>}
            </View>
          )}
        </View>

        {/* Invite Form */}
        <View>
          <Text style={{ fontSize: 17, fontWeight: "800", color: colors.textMain, marginBottom: 12 }}>Invite New Member</Text>
          <View style={{ backgroundColor: "white", borderRadius: 24, borderWidth: 1, borderColor: colors.border, padding: 20, gap: 16 }}>
            <TextInput
              placeholder="Name"
              value={name}
              onChangeText={setName}
              style={{ backgroundColor: "#F7F7F8", borderRadius: 12, padding: 16, fontSize: 15, fontWeight: "700", color: colors.textMain }}
            />
            <TextInput
              placeholder="Phone Number"
              value={phone}
              onChangeText={setPhone}
              keyboardType="phone-pad"
              style={{ backgroundColor: "#F7F7F8", borderRadius: 12, padding: 16, fontSize: 15, fontWeight: "700", color: colors.textMain }}
            />
            <View style={{ flexDirection: "row", gap: 12 }}>
              <TouchableOpacity onPress={() => setRole("manager")} style={{ flex: 1, padding: 12, borderRadius: 12, borderWidth: 1, borderColor: role === "manager" ? colors.primary : colors.border, backgroundColor: role === "manager" ? "#E8F0EC" : "white", alignItems: "center" }}>
                <Text style={{ fontWeight: "700", color: role === "manager" ? colors.primary : colors.textMuted }}>Manager</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => setRole("owner")} style={{ flex: 1, padding: 12, borderRadius: 12, borderWidth: 1, borderColor: role === "owner" ? colors.primary : colors.border, backgroundColor: role === "owner" ? "#E8F0EC" : "white", alignItems: "center" }}>
                <Text style={{ fontWeight: "700", color: role === "owner" ? colors.primary : colors.textMuted }}>Owner</Text>
              </TouchableOpacity>
            </View>
            <TouchableOpacity onPress={handleInvite} disabled={inviting || !name || !phone} style={{ backgroundColor: colors.primary, borderRadius: 16, padding: 16, alignItems: "center", marginTop: 8, opacity: inviting || !name || !phone ? 0.7 : 1 }}>
              <Text style={{ color: "white", fontSize: 15, fontWeight: "800" }}>{inviting ? "Sending..." : "Send Invitation"}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
